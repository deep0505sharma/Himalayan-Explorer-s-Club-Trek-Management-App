<?php
// Step 1: Require the database connection file
require_once 'db_con.php';

// Step 2: Check if all values in the POST array are set
if (isset($_POST['firstName'], $_POST['lastName'], $_POST['email'], $_POST['password'],
 $_POST['enrollmentNumber'], $_POST['gender'], $_POST['whatsappNumber'], $_POST['hostel'],
  $_POST['department'], $_POST['year'])) {
    // Step 3: Check if a user with the given email already exists in the table
    $email = $_POST['email'];

    $sql_email_check = "SELECT * FROM users WHERE email='$email'";
    $result_email_check = $conn->query($sql_email_check);

    if ($result_email_check->num_rows > 0) {
        // Email already exists, redirect back to index page with error message
        header("Location: r.php?error=Email%20already%20exists");
        exit; // Exit the script to prevent further execution
    }

    // Step 4: Check if a user with the given enrollment number already exists in the table
    $enrollmentNumber = $_POST['enrollmentNumber'];

    $sql_enrollment_check = "SELECT * FROM users WHERE enrollmentNumber='$enrollmentNumber'";
    $result_enrollment_check = $conn->query($sql_enrollment_check);

    if ($result_enrollment_check->num_rows > 0) {
        // Enrollment number already exists, redirect back to index page with error message
        header("Location: r.php?error=Enrollment%20number%20already%20exists");
        exit; // Exit the script to prevent further execution
    }

    // Step 5: Check if a user with the given WhatsApp number already exists in the table
    $whatsappNumber = $_POST['whatsappNumber'];

    $sql_whatsapp_check = "SELECT * FROM users WHERE whatsappNumber='$whatsappNumber'";
    $result_whatsapp_check = $conn->query($sql_whatsapp_check);

    if ($result_whatsapp_check->num_rows > 0) {
        // WhatsApp number already exists, redirect back to index page with error message
        header("Location: r.php?error=WhatsApp%20number%20already%20exists");
        exit; // Exit the script to prevent further execution
    }

    // Step 6: Execute SQL query to insert user data into the users table
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $password = $_POST['password']; // Password field
    $gender = $_POST['gender'];
    $hostel = $_POST['hostel'];
    $department = $_POST['department'];
    $year = $_POST['year'];

    // You should hash the password before storing it in the database for security
    $hashed_password = md5($password);

    $sql_insert = "INSERT INTO users (firstName, lastName, email, password, 
    enrollmentNumber, gender, whatsappNumber, hostel, department, year) VALUES
     ('$firstName', '$lastName', '$email', '$hashed_password', '$enrollmentNumber', '$gender', '$whatsappNumber', '$hostel', '$department', '$year')";

    if ($conn->query($sql_insert) === TRUE) {
        // Registration successful, redirect to login page with success message
        header("Location: index.php?message=Registration%20successful.%20Login%20to%20continue.");
        exit;
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
} else {
    // All fields are required, redirect back to index page with error message
    header("Location: r.php?error=All%20fields%20are%20required");
    exit;
}
?>
