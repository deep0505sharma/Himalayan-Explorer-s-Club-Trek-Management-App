<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Feed</title>
<link rel="stylesheet" type="text/css" href="css/feed.css">
</head>
<body>
<div class="containerc">
<h1> All recent events</h1>
<?php
// Include the general header file
require_once 'general.php';
require_once 'functions.php';

// Check if the user is logged in
if (!isLoggedIn($conn)) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit;
}

// Initialize variables for user ID
$userId = null;

// Check if the enrollment number or phone number cookie and password cookie are set
if ((isset($_COOKIE['enrollmentNumber']) || isset($_COOKIE['whatsappNumber'])) && isset($_COOKIE['password'])) {
    // Retrieve enrollment number or phone number and password from cookies
    $enrollmentNumber = isset($_COOKIE['enrollmentNumber']) ? $_COOKIE['enrollmentNumber'] : null;
    $whatsappNumber = isset($_COOKIE['whatsappNumber']) ? $_COOKIE['whatsappNumber'] : null;
    $password = $_COOKIE['password'];

    // Query the database to find the user with the provided credentials
    $stmt = $conn->prepare("SELECT id FROM users WHERE (enrollmentNumber = ? OR whatsappNumber = ?) AND password = ?");
    $stmt->bind_param("sss", $enrollmentNumber, $whatsappNumber, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a user is found
    if ($result->num_rows > 0) {
        // Fetch the user ID from the result set
        $row = $result->fetch_assoc();
        $userId = $row['id'];
    }
}


// Fetch latest 10 events from the database
$sql = "SELECT * FROM events ORDER BY id DESC LIMIT 10";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output each event as a card
    while ($row = $result->fetch_assoc()) {
        $trekName = $row['name'];
        $trekDescription = $row['description'];
        $trekDate = $row['date'];
        $totalCost = $row['totalcost'];
        $registrationCost = $row['rcost'];
        $trekLeader1 = $row['trekleader1'];
        $trekLeaderContact1 = $row['contact1'];
        $trekLeader2 = $row['trekleader2'];
        $trekLeaderContact2 = $row['contact2'];
        $image1 = $row['img1'];
        $image2 = $row['img2'];
        $id = $row['id'];

        //check if alredy registered
        if ($userId) {
            $registrationQuery = "SELECT * FROM registrations WHERE user_id = ? AND trek_id = ?";
            $stmt = $conn->prepare($registrationQuery);
            $stmt->bind_param("ss", $userId, $id);
            $stmt->execute();
            $registrationResult = $stmt->get_result();

            if ($registrationResult->num_rows > 0) {
                // User is already registered for this event
                $alreadyRegistered = true;
            } else {
                $alreadyRegistered = false;
            }
        } else {
            // User ID not found, assume not registered
            $alreadyRegistered = false;
        }

?>

<div class="card">
    <div class="preload-images">
        <style>.preload-images {
    display: none;
    background-image: url('uploads/<?php echo $image1; ?>');
    background-image: url('uploads/<?php echo $image2; ?>');
}</style>
    </div>
    <div class="image-container">
        <div class="image active" style="background-image: url('uploads/<?php echo $image1; ?>');"></div>
        <div class="image" style="background-image: url('uploads/<?php echo $image2; ?>');"></div>
        <button class="prev-btn" onclick="changeSlide(this, -1)">&#10094;</button>
        <button class="next-btn" onclick="changeSlide(this, 1)">&#10095;</button>
    </div>
    <div class="trek-info">
        <h2><?php echo $trekName; ?></h2>
        <p><b>Date:</b> <?php echo $trekDate; ?></p>
        <p><b>Total Cost:</b> <?php echo $totalCost; ?></p>
        <p><b>Registration Cost:</b> <?php echo $registrationCost; ?></p>
        <p><b>Trek Leader 1:</b> <?php echo $trekLeader1; ?> - <?php echo $trekLeaderContact1; ?></p>
        <p><b>Trek Leader 2:</b> <?php echo $trekLeader2; ?> - <?php echo $trekLeaderContact2; ?></p>
        <p class="shortdes"><?php echo nl2br(substr($trekDescription, 0, 200)); ?> </p>
        <div  style="display: none;"><?php echo nl2br($trekDescription); ?></div>
        <a href="#" class="more-link">...read more.</a></p>
        <button class="register-button" onclick='paisado("<?php echo $id?>")' id="btn-<?php echo $id;?>"
        <?php if ($alreadyRegistered) {echo 'disabled '; echo'style="background-color:green !important;"';}?>><?php echo $alreadyRegistered ? "Already Registered &check;
" : "Register"; ?></button>
    </div>
</div>

<?php
    }
} else {
    echo "No events found.";
}
?>
</div>
<script src="script/feed.js"></script>
<?php require 'footer.php';?>
</body>
</html>
