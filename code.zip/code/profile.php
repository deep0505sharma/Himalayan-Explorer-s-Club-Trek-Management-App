<?php
// Include necessary files
require_once 'db_con.php';
require_once 'functions.php';

// Check if the user is logged in
if (!isLoggedIn($conn)) {
    // Redirect to the login page if not logged in
    header("Location: index.php");
    exit;
}

// Check if the user ID is set in the GET array
if (!isset($_GET['userid'])) {
    // Redirect to the feed page if user ID is not provided
    header("Location: feed.php");
    exit;
}

// Get the user ID from the GET array
$userId = $_GET['userid'];

// Query the database to fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    // Fetch user details
    $user = $result->fetch_assoc();
    $fullName = getFullName($conn,$userId);
    $initials = getUserInitials($conn,$userId);

    // Query the database to fetch previous treks attended by the user
    $treksStmt = $conn->prepare("SELECT e.name, e.date FROM registrations r INNER JOIN events e ON r.trek_id = e.id WHERE r.user_id = ?");
    $treksStmt->bind_param("i", $userId);
    $treksStmt->execute();
    $treksResult = $treksStmt->get_result();

    // Array to store previous treks attended
    $previousTreks = array();

    // Fetch and store previous treks attended
    while ($row = $treksResult->fetch_assoc()) {
        $previousTreks[] = $row;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile</title>
<link rel="stylesheet" type="text/css" href="css/profile.css">
</head>
<body>
    <?php require 'general.php';?>
<div class="profile-card">
    <div class="profile-header">
        <div class="profile-initials"><?php echo $initials; ?></div>
        <h2 class="profile-name"><?php echo $fullName; ?></h2>
    </div>
    <div class="profile-info">
        <p><b>Email:</b> <?php echo $user['email']; ?></p>
        <p><b>Enrollment Number:</b> <?php echo $user['enrollmentNumber']; ?></p>
        <p><b>Department:</b> <?php echo $user['department']; ?></p>
        <p><b>Year:</b> <?php echo $user['year']; ?></p>
        <p><b>Gender:</b> <?php echo $user['gender']; ?></p>
        <p><b>WhatsApp Number:</b> <?php echo $user['whatsappNumber']; ?></p>
        <p><b>Hostel:</b> <?php echo $user['hostel']; ?></p>
    </div>
    <div class="previous-treks">
        <h3>Previous Treks Attended:</h3>
        <ul>
            <?php foreach ($previousTreks as $trek): ?>
                <li><?php echo $trek['name'] . " - " . $trek['date']; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

</body>
<?php require 'footer.php';?>
</html>
<?php
} else {
    // Redirect to the feed page if user does not exist
    header("Location: feed.php");
    exit;
}
?>
