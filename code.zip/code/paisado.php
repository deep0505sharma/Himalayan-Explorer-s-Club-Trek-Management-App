<?php
// Include necessary files
require_once 'db_con.php';
require_once 'functions.php';

// Check if the trek ID is set in the POST array
if (!isset($_POST['trekid'])) {
    header("Location: feed.php");
    exit;
}

// Check if the enrollment number or phone number cookie and password cookie are set
if ((isset($_COOKIE['enrollmentNumber']) || isset($_COOKIE['whatsappNumber'])) && isset($_COOKIE['password'])) {
    // Retrieve enrollment number or phone number and password from cookies
    $enrollmentNumber = isset($_COOKIE['enrollmentNumber']) ? $_COOKIE['enrollmentNumber'] : null;
    $whatsappNumber = isset($_COOKIE['whatsappNumber']) ? $_COOKIE['whatsappNumber'] : null;
    $password = $_COOKIE['password'];

    // Query the database to find the user with the provided credentials
    $stmt = $conn->prepare("SELECT id FROM users WHERE (enrollmentNumber = ? OR whatsappNumber = ?) AND password = ?");
    $stmt->bind_param("sss", $enrollmentNumber, $whatsappNumber, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if a user is found
    if ($result->num_rows > 0) {
        // Fetch the user ID from the result set
        $row = $result->fetch_assoc();
        $userId = $row['id'];

        // Check if the user has previously registered for the trek
        $trekId = $_POST['trekid'];
        $query = "SELECT * FROM registrations WHERE user_id = ? AND trek_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $userId, $trekId);
        $stmt->execute();
        $result = $stmt->get_result();

        // If the user has previously registered
        if ($result->num_rows > 0) {
            echo "You have already registered for this trek.";
        } else {
            // Insert the record into the registrations table
            $insertQuery = "INSERT INTO registrations (user_id, trek_id, payment_id, payment_status) VALUES (?, ?, 1, 'Pending')";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("ii", $userId, $trekId);
            if ($insertStmt->execute()) {
                echo "Registration successful!"; // Display success message
            } else {
                echo "Error occurred while registering."; // Display error message if insertion fails
            }
        }
    } else {
        // Handle case where user is not found or credentials are invalid
        echo "Invalid user!";
    }
} else {
    echo "Invalid user!";
    exit;
}
?>
