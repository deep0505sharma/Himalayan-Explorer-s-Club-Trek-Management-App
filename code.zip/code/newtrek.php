<?php
// Check if admin username and password cookies are set
if (!isset($_COOKIE['admin_username']) || !isset($_COOKIE['admin_password'])) {
    // Redirect to admin.php if cookies are not set
    header("Location: admin.php?error=Please login as admin");
    exit;
}

// Include database connection file
require_once 'db_con.php';

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $trekName = $_POST['trekName'];
    $trekDuration = $_POST['trekDuration'];
    $trekLeader1 = $_POST['trekLeader1'];
    $trekLeaderContact1 = $_POST['trekLeaderContact1'];
    $trekLeader2 = $_POST['trekLeader2'];
    $trekLeaderContact2 = $_POST['trekLeaderContact2'];
    $totalCost = $_POST['totalCost'];
    $registrationCost = $_POST['registrationCost'];
    $trekDescription = $_POST['trekDescription'];
    $trekDate = $_POST['trekDate'];

    // Generate unique image names based on timestamp
    $image1Name = time() . '_img1.' . pathinfo($_FILES["trekImage1"]["name"], PATHINFO_EXTENSION);
    $image2Name = time() . '_img2.' . pathinfo($_FILES["trekImage2"]["name"], PATHINFO_EXTENSION);

    // Upload images to directory
    $targetDir = "uploads/";
    $trekImage1 = $targetDir . $image1Name;
    $trekImage2 = $targetDir . $image2Name;

    // Check file extensions
    $imageFileType1 = strtolower(pathinfo($trekImage1, PATHINFO_EXTENSION));
    $imageFileType2 = strtolower(pathinfo($trekImage2, PATHINFO_EXTENSION));

    if ($imageFileType1 != "jpg" && $imageFileType1 != "jpeg" && $imageFileType1 != "png" && $imageFileType1 != "gif" &&
        $imageFileType2 != "jpg" && $imageFileType2 != "jpeg" && $imageFileType2 != "png" && $imageFileType2 != "gif") {
        // Error uploading images - Invalid file format
        header("Location: manage.php?error=Invalid file format. Only JPG, JPEG, PNG, and GIF files are allowed.");
        exit;
    }

    if (move_uploaded_file($_FILES["trekImage1"]["tmp_name"], $trekImage1) &&
        move_uploaded_file($_FILES["trekImage2"]["tmp_name"], $trekImage2)) {
        // Image uploaded successfully, proceed to insert data into database
        // Prepare SQL statement with placeholders
        $sql = "INSERT INTO events (name, duration, trekleader1, contact1, trekleader2, contact2, totalcost, rcost, description, date, img1, img2)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Prepare the SQL statement
        $stmt = mysqli_prepare($conn, $sql);

        // Bind parameters to the prepared statement
        mysqli_stmt_bind_param($stmt, "ssssssssssss", $trekName, $trekDuration, $trekLeader1, $trekLeaderContact1, $trekLeader2, $trekLeaderContact2, $totalCost, $registrationCost, $trekDescription, $trekDate, $image1Name, $image2Name);

        // Execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            // Trek data inserted successfully
            header("Location: manage.php?message=Trek added successfully");
            exit;
        } else {
            // Error inserting trek data into database
            header("Location: manage.php?error=Error adding trek: " . mysqli_error($conn));
            exit;
        }

        // Close statement
        mysqli_stmt_close($stmt);
    } else {
        // Error uploading images
        header("Location: manage.php?error=Error uploading images");
        exit;
    }
} else {
    // Redirect if form data is not submitted
    header("Location: manage.php?error=Form data not submitted");
    exit;
}
?>
