<?php
// Check if the user is already logged in
if (isset($_COOKIE['password']) and (isset($_COOKIE['enrollmentNumber']) or isset($_COOKIE['whatsappNumber']))) {
    // If username and password cookies are set, verify credentials against the database
    // Your code to verify credentials here
    // If credentials are valid, redirect to the dashboard or home page
    header("Location: feed.php");
    exit;
}

// Check if error message is present in GET array
$error_message = isset($_GET['error']) ? $_GET['error'] : '';

// Check if success message is present in GET array
$success_message = isset($_GET['message']) ? $_GET['message'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="css/login.css">
<script type="text/javascript" src="script/login.js"></script>
</head>
<body>
<?php 
include('general.php');
?>
<div class="container">
    <h2>Login</h2>
    <form id="loginForm" method="post" action="login.php">

        <!-- Display error message if present -->
        <?php if ($error_message): ?>
        <div class="error">*Error: <?php echo $error_message; ?></div>
        <?php endif; ?>
        <!-- Display success message if present -->
        <?php if ($success_message): ?>
        <div class="success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <input type="text" name="loginIdentifier" placeholder="Phone or Enrollment" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Login">
        <p><a href="#channeli">Login with channel i</a><br>
        Not registered? <a href="r.php">Register</a></p>
    </form>
    
</div>
<?php require 'footer.php';?>
</body>
</html>
