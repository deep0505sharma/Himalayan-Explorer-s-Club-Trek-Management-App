<?php
// Include necessary files
require_once 'functions.php';

// Check if the user is logged in
if (isLoggedIn($conn)) {
    $userid = getUserId($conn);
    // If logged in, fetch user details
    $userName = getFullName($conn,$userid); // Assuming this function retrieves the user's full name
    $userInitials = getUserInitials($conn,$userid); // Assuming this function retrieves the user's initials
} else {
    // If not logged in, display "Guest User"
    $userName = "Guest User";
    $userInitials = "GU";
}
?>

<link rel="stylesheet" type="text/css" href="css/general.css">
<script type="text/javascript" src="script/general.js"></script>

<div id="header">
    <div id="menuIcon">&#9776;</div>
    <h3>Himalayan Explorers' Club</h3>
    <img src="img/logo.png" alt="Logo" id="logo">
</div>

<div id="menu" class="menu">
    <div id="closeIcon">&times;</div>
    <div id="userDetails">
        <div id="userInitials"><?php echo $userInitials; ?></div>
        <span id="userName"><?php echo $userName; ?></span>
    </div>
    <br>
    <ul>
        
        <li><a href="profile.php?userid=<?php echo $userid;?>">Profile</a></li>
        <hr>
        <li><a href="feed.php">Treks</a></li>
        <hr>
        <li><a href="blog.php">Blog</a></li>
        <hr>
        <li><a href="admin.php">Admin portal</a></li>
        <hr>
        <li><a href="contact.php">Contact Us</a></li>
        <hr>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
