<footer class="custom-footer">
    <div class="footer-content">
        <div class="club-info">
            <h3>Himalayan Explorers Club</h3>
            <p>A community of adventure enthusiasts exploring the Himalayas.</p>
            <p>Contact us: hec@iitr.ac.in | Phone: +91 7006163990</p>
        </div>
        <div class="footer-logo"><img src="img/iitlogo.png" alt="lohgo"></div>
</div>
</footer>
