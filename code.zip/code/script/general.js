// Hide the header when scrolled down and show when scrolled up
var lastScrollTop = 0;
window.addEventListener("scroll", function(){
    var currentScroll = window.pageYOffset || document.documentElement.scrollTop;
    if (currentScroll > lastScrollTop && window.scrollY > 40){
        document.getElementById("header").style.top = "-80px";
    } else {
        document.getElementById("header").style.top = "0";
    }
    lastScrollTop = currentScroll;
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("menuIcon").addEventListener("click", function() {
        document.getElementById("menu").classList.toggle("active");
    });
    document.getElementById("closeIcon").addEventListener("click",function(){
        document.getElementById("menu").classList.toggle("active");
    });
});

