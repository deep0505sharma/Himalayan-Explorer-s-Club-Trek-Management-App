// Function to change slide
function changeSlide(button, direction) {
    // Get the card element containing the button
    var card = button.closest('.card');
    
    // Get all image elements inside the card
    var images = card.querySelectorAll('.image');
    
    // Find the currently active image
    var currentIndex = -1; // Initialize to an invalid value
    images.forEach(function(image, index) {
        if (image.classList.contains('active')) {
            currentIndex = index;
        }
    });

    // Check if currentIndex is valid
    if (currentIndex === -1) {
        console.error('No active image found.');
        return; // Exit the function if no active image is found
    }

    // Calculate the index of the next image
    var nextIndex = currentIndex + direction;
    if (nextIndex < 0) {
        nextIndex = images.length - 1; // Loop back to the last image
    } else if (nextIndex >= images.length) {
        nextIndex = 0; // Loop back to the first image
    }

    // Remove 'active' class from the current image
    images[currentIndex].classList.remove('active');
    
    // Add 'active' class to the next image
    images[nextIndex].classList.add('active');
}
document.addEventListener('DOMContentLoaded', function() {
    const moreLinks = document.querySelectorAll('.more-link');
    moreLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const descriptionDiv = this.parentElement.querySelector('div');
            const tobehiddenDiv = this.parentElement.querySelector('.shortdes')
            if (descriptionDiv.style.display === 'none') {
                descriptionDiv.style.display = 'block';
                tobehiddenDiv.style.display = 'none';
                this.innerText = '...read lesser.';
            } else {
                descriptionDiv.style.display = 'none';
                this.innerText = '...read more.';
                tobehiddenDiv.style.display = 'block';
            }
        });
    });
});
function paisado(id) {
    fetch('paisado.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'trekid=' + id,
        credentials: 'include', // Include cookies in the request
    })
    .then(response => response.text())
    .then(data => {
        // Check if the response indicates successful registration
            const  btn_id = "btn-"+id; 
            const registerButton = document.getElementById(btn_id);
        if (data.trim() === "Registration successful!") {
            // Get the button element
            if (registerButton) {
                // Change button color to green
                registerButton.style.backgroundColor = 'green';
                // Modify button text
                registerButton.innerHTML = 'Registration Successful &check;';
                // Disable the button
                registerButton.disabled = true;
            }
        } else {
            const errormsg =error+" Click again to try.";
           registerButton.innerHTML(errormsg); // Display other response messages in alert
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
