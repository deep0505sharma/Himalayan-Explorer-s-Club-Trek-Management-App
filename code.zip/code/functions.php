<?php
// Function to check if the user is already logged in
require("db_con.php");
function isLoggedIn($conn) {
    // Check if enrollment number and password cookies are set
    if (isset($_COOKIE['enrollmentNumber']) && isset($_COOKIE['password'])) {
        $enrollmentNumber = $_COOKIE['enrollmentNumber'];
        $password = $_COOKIE['password'];

        // Check if the user exists in the database
        $sql = "SELECT * FROM users WHERE enrollmentNumber = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $enrollmentNumber, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User exists, return true
            return true;
        }
    } elseif (isset($_COOKIE['whatsappNumber']) && isset($_COOKIE['password'])) {
        $whatsappNumber = $_COOKIE['whatsappNumber'];
        $password = $_COOKIE['password'];

        // Check if the user exists in the database
        $sql = "SELECT * FROM users WHERE whatsappNumber = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $whatsappNumber, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User exists, return true
            return true;
        }
    }

    // User is not logged in, return false
    return false;
}

// Function to get the full name of the user
function getFullName($conn,$userId) {
    // Check if the connection is valid
    // Check if enrollment number or WhatsApp number cookie is set
        // Query to retrieve the user's full name based on enrollment number or WhatsApp number
        $sql = "SELECT CONCAT(firstName, ' ', lastName) AS full_name FROM users WHERE id=$userId";

        // Prepare the statement
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return "Database error: " . $conn->error;
        }

        // Bind the parameters and execute the statement
        $stmt->execute();

        // Store the result
        $result = $stmt->get_result();

        // Check if the result contains data
        if ($result->num_rows > 0) {
            // Fetch the row and retrieve the full name
            $row = $result->fetch_assoc();
            $fullName = $row['full_name'];

            // Return the full name
            return $fullName;
        } else {
            return "User not found";
        }
}


// Function to get the user's initials from both first and last names
function getUserInitials($conn,$userId) {
    // Check if the connection is valid

    // Check if enrollment number or WhatsApp number cookie is set

        // Query to retrieve the user's first and last names based on enrollment number or WhatsApp number
        $sql = "SELECT firstName, lastName FROM users WHERE id=$userId";

        // Prepare the statement
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return "Database error: " . $conn->error;
        }
        $stmt->execute();

        // Store the result
        $result = $stmt->get_result();

        // Check if the result contains data
        if ($result->num_rows > 0) {
            // Fetch the row and retrieve the first and last names
            $row = $result->fetch_assoc();
            $firstName = $row['firstName'];
            $lastName = $row['lastName'];

            // Get the initials from the first and last names
            $initials = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));

            // Return the initials
            return $initials;
        } else {
            return "User not found";
        }
}



function getUserId($conn) {
    // Check if the connection is valid

    // Check if enrollment number or WhatsApp number cookie is set
    if (isset($_COOKIE['enrollmentNumber']) || isset($_COOKIE['whatsappNumber'])) {
        // Retrieve enrollment number or WhatsApp number from cookies
        $enrollmentNumber = isset($_COOKIE['enrollmentNumber']) ? $_COOKIE['enrollmentNumber'] : null;
        $whatsappNumber = isset($_COOKIE['whatsappNumber']) ? $_COOKIE['whatsappNumber'] : null;
        
        // Retrieve password from cookie
        $password = $_COOKIE['password'];

        // Query to retrieve the user's first and last names based on enrollment number or WhatsApp number
        $sql = "SELECT id FROM users WHERE (enrollmentNumber = ? OR whatsappNumber = ?) AND password = ?";

        // Prepare the statement
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return "Database error: " . $conn->error;
        }

        // Bind the parameters and execute the statement
        $stmt->bind_param("sss", $enrollmentNumber, $whatsappNumber, $password);
        $stmt->execute();

        // Store the result
        $result = $stmt->get_result();

        // Check if the result contains data
        if ($result->num_rows > 0) {
            // Fetch the row and retrieve the first and last names
            $row = $result->fetch_assoc();
            $userid = $row["id"];
            return $userid;
        } else {
            return "User not found";
        }
    } else {
        return "Cookies not set";
    }
}
// Function to check if the user is logged in as admin
function isAdminLoggedIn($conn) {
    if (isset($_COOKIE['admin_username']) && isset($_COOKIE['admin_password'])) {
        $adminUsername = $_COOKIE['admin_username'];
        $adminPassword = $_COOKIE['admin_password'];
    return true;
}
else{
    return false;
}
}
?>

