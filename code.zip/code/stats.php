<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="css/stats.css">
<script type="text/javascript" src="script/stats.js"></script>
<style>
    /* CSS for triangles */
    .show-profile {
        display: inline-block;
        cursor: pointer;
        margin-left: 10px;
    }
    .triangle {
        width: 0;
        height: 0;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-bottom: 8px solid black;
        display: inline-block;
    }
    .up-triangle {
        transform: rotate(180deg);
    }
</style>
</head>
<body>
<?php
// Include necessary files
require_once 'db_con.php';
require_once 'functions.php';

// Check if the user is logged in as admin
if (!isAdminLoggedIn($conn)) {
    // Redirect to the login page if not logged in as admin
    header("Location: index.php");
    exit;
}
require 'general.php';
echo '<br><br><br>';
?>
<h2 id="hstat"> <a href="manage.php">Add Trek</a> | Statistics </h2>
<?php
// Fetch the last 3 treks from the database
$trekQuery = "SELECT * FROM events ORDER BY id DESC LIMIT 3";
$trekResult = $conn->query($trekQuery);

if ($trekResult->num_rows > 0) {
    // Output registrations for each trek
    while ($trekData = $trekResult->fetch_assoc()) {
        $trekId = $trekData['id'];
        
        // Display trek details
        echo '<div class="trek-details">';
        echo '<h2>' . $trekData['name'] . '</h2><hr>';
        echo '<p class="trek-date">Date: ' . $trekData['date'] . '</p>';
        // Add more trek details as needed
        // Fetch registrations for the current trek
        $registrationQuery = "SELECT * FROM registrations WHERE trek_id = $trekId";
        $registrationResult = $conn->query($registrationQuery);
        
        if ($registrationResult->num_rows > 0) {
            // Output registrations for the current trek
            $userial = 0;
            $totalregs = $registrationResult->num_rows;
            echo '<p class="reg-count">Total registrations: ' . $totalregs.'<hr>';
            while ($registrationData = $registrationResult->fetch_assoc()) {
                $userial++;
                $userIdstat = $registrationData['user_id'];
                
                // Fetch user details for the current registration
                $userQuery = "SELECT * FROM users WHERE id = $userIdstat";
                $userResult = $conn->query($userQuery);
                
                if ($userResult->num_rows > 0) {
                    // Output user details for the current registration
                    $userData = $userResult->fetch_assoc();
                    echo '<div class="user-details">';
                    echo '<p class="name-cu">' .$userial.') '. $userData['firstName'] . ' ' . $userData['lastName'] .
                         '<span class="show-profile">&#9660;</span></p>'; // Triangle added here
                    // Add more user details as needed
                    //profile card
                    $initials2 = getUserInitials($conn,$userData['id']);
                    $fullName2 = getFullName($conn, $userData['id']);
                    ?>
                        <div class="profile-card" style="display: none;"> <!-- Added inline style to hide profile initially -->
                            <div class="profile-header">
                                <div class="profile-initials"><?php echo $initials2; ?></div>
                                <h2 class="profile-name"><?php echo $fullName2; ?></h2>
                            </div>
                            <div class="profile-info">
                                <p><b>Email:</b> <?php echo $userData['email']; ?></p>
                                <p><b>Enrollment Number:</b> <?php echo $userData['enrollmentNumber']; ?></p>
                                <p><b>Department:</b> <?php echo $userData['department']; ?></p>
                                <p><b>Year:</b> <?php echo $userData['year']; ?></p>
                                <p><b>Gender:</b> <?php echo $userData['gender']; ?></p>
                                <p><b>WhatsApp Number:</b> <?php echo $userData['whatsappNumber']; ?></p>
                                <p><b>Hostel:</b> <?php echo $userData['hostel']; ?></p>
                            </div>
                        </div>
                    <!--profile card ends here-->
                    <?php
                    echo "</div>";
                } else {
                    echo "User details not found.";
                }
            }
        } else {
            echo "No registrations found for this trek.";
    
        }
        echo "</div>";
    }
} else {
    echo "No treks found.";
}
?>

<script>
// JavaScript to toggle profile visibility
document.addEventListener('DOMContentLoaded', function() {
    const profileParagraphs = document.querySelectorAll('.show-profile');
    profileParagraphs.forEach(function(paragraph) {
        paragraph.addEventListener('click', function() {
            const profileCard = this.parentNode.nextElementSibling;
            profileCard.style.display = profileCard.style.display === 'none' ? 'block' : 'none';
            this.innerHTML = profileCard.style.display === 'none' ? '&#9660;' : '&#9650;'; // Toggle triangle
        });
    });
});
</script>
<?php
echo '<br>';
require 'footer.php';
?>
</body>
</html>
