<?php
// Check if admin username and password cookies are set
if (!isset($_COOKIE['admin_username']) || !isset($_COOKIE['admin_password'])) {
    // Redirect to admin.php if cookies are not set
    header("Location: admin.php");
    exit;
}

// Check if error message is present in GET array
$error_message = isset($_GET['error']) ? $_GET['error'] : '';

// Check if success message is present in GET array
$success_message = isset($_GET['message']) ? $_GET['message'] : '';
// Include any necessary files or configurations here

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage</title>
<link rel="stylesheet" type="text/css" href="css/manage.css">
</head>
<body>
<?php
require 'general.php';
?>
<div class="container">
<h2 id="hstat">Add Trek | <a href="stats.php">Statistics </a></h2>
    <form id="newTrekForm" method="post" action="newtrek.php" enctype="multipart/form-data">
        <!-- Text input fields with placeholders -->
         <!-- Display error message if present -->
         <?php if ($error_message): ?>
        <div class="error">*Error: <?php echo $error_message; ?></div>
        <?php endif; ?>
        <!-- Display success message if present -->
        <?php if ($success_message): ?>
        <div class="success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <div class="input-group">
            <input type="text" name="trekName" placeholder="Trek Name" required id="trekName">
        </div>

        <div class="input-group">
            <input type="number" id="trekDuration" name="trekDuration" placeholder="Trek Duration (in days)" required>
        </div>

        <div class="input-group">
            <input type="text" name="trekLeader1" placeholder="Trek Leader 1" required>
        </div>

        <div class="input-group">
            <input type="text" name="trekLeaderContact1" placeholder="Trek Leader 1 Contact" required>
        </div>

        <div class="input-group">
            <input type="text" name="trekLeader2" placeholder="Trek Leader 2">
        </div>

        <div class="input-group">
            <input type="text" name="trekLeaderContact2" placeholder="Trek Leader 2 Contact">
        </div>

        <!-- Text input fields for total cost and registration cost -->
        <div class="input-group">
            <input type="text" id="totalCost" name="totalCost" placeholder="Total Cost" required>
        </div>

        <div class="input-group">
            <input type="text" name="registrationCost" placeholder="Registration Cost" required>
        </div>

        <!-- Textarea input field with placeholder -->
        <div class="input-group">
            <textarea name="trekDescription" id="trekDescription" placeholder="Trek Description" rows="10" cols="50" required></textarea>
         <!-- Button to auto generate description -->
         <button type="button" id="generateDescriptionBtn">Auto Generate</button>
    
        </div>

        <!-- File input fields with label -->
        <div class="input-group">
            <label for="trekDate" >Trek Date:</label>
            <input type="date" name="trekDate" id="trekDate" required>
        </div>

        <div class="input-group-file">
            <label for="trekImage1" id="l1">Choose first image<input type="file" name="trekImage1" id="trekImage1" required></label>
        </div>

        <div class="input-group-file">
            <label for="trekImage2" id="l2">Choose second image <input type="file" id="trekImage2" name="trekImage2" required></label>
            
        </div>
        <div id="imgDisp"></div>
        <input type="submit" value="Upload Trek">
    </form>
</div>


<!-- Script to handle auto generation of description -->

<script>
// Function to handle response from LlamaAI and update textarea
function handleResponse(data) {
    // Extract the generated content from the assistant message
    const generatedContent = data.choices[0].message.content;
    // Modify the generated content to include user-provided information
    const updatedContent = generatedContent;
    // Update the textarea with the generated description
    document.getElementById("trekDescription").value = updatedContent;
    // Reset button properties after generating content
    document.getElementById("generateDescriptionBtn").innerText = "Generated";
    document.getElementById("generateDescriptionBtn").style.backgroundColor = "green";
}

// Function to generate dynamic description using LlamaAI
function generateDynamicDescription() {
    const trekName = document.getElementById("trekName").value;
    const trekDuration = document.getElementById("trekDuration").value;
    const totalCost = document.getElementById("totalCost").value;
    const date = document.getElementById("trekDate").value;

    // Check if all required fields are filled
    if (trekName && trekDuration && totalCost &&trekDate) {
        // Change button text to "Generating" and update background color
        document.getElementById("generateDescriptionBtn").innerText = "Generating...";
        document.getElementById("generateDescriptionBtn").style.backgroundColor = "#ccc";

        // Build the request payload for LlamaAI
        const requestBody = {
            messages: [
                { role: "user", content: `Generate a short description to be used by the Himalayan Explorers Club, IITR for organizing a trek to ${trekName}. Include details like trek distances and altitudes. The cost is ${totalCost} and duration is ${trekDuration} starting date is ${date}` }
            ],
            stream: false,
            function_call: "none"
        };

        // Send POST request to LlamaAI
        fetch("https://api.llama-api.com/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer LL-Vz4XMDlm8CJB50EoHpWiVPtVCVmD7nOeMBiB94cQgbIzdH6gkyhZ9DgNvGx0Ardk"
            },
            body: JSON.stringify(requestBody)
        })
        .then(response => response.json())
        .then(handleResponse)
        .catch(error => {
            console.error('Error:', error);
            // Reset button properties if an error occurs
            document.getElementById("generateDescriptionBtn").innerText = "Generate";
            document.getElementById("generateDescriptionBtn").style.backgroundColor = "#007bff";
        });
    } else {
        alert("Please fill in trekname, trekcost, trekduration and date before autogenerating.");
    }
}

// Add event listener to the button for generating description
document.getElementById("generateDescriptionBtn").addEventListener("click", generateDynamicDescription);

// Function to update label style when file is selected or deselected
function updateLabelStyle(fileInputId,fileInputId2, labelId) {
    const fileInput = document.getElementById(fileInputId);
    const fileInput2 = document.getElementById(fileInputId2);
    const label = document.getElementById(labelId);
    const displaydiv = document.getElementById("imgDisp");
    // Event listener for file input change
    fileInput.addEventListener("change", function() {
        if (fileInput.files.length > 0) {
            label.style.backgroundColor = "green"; // Change background color when file is selected
            if(fileInput2.files.length>0){
            displaydiv.innerHTML ="Both images chosen. Click buttons again to change images!";
            }
        } else {
            label.style.backgroundColor = ""; // Reset background color when no file is selected
            displaydiv.innerHTML ="";
        }
    });
}

// Call the function for each file input and corresponding label
updateLabelStyle("trekImage1","trekImage2", "l1");
updateLabelStyle("trekImage2","trekImage1", "l2");

</script>
<?php require 'footer.php';?>
</body>
</html>