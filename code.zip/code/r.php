<?php
// Check if error message is present in GET array
$error_message = isset($_GET['error']) ? $_GET['error'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript" src="script/register.js"></script>
<title>Registration Form</title>
<link rel="stylesheet" type="text/css" href="css/register.css">
</head>
<body>

<!--include general header and menu-->
<?php 
include('general.php')
?>
<!--general inclusion ends here-->
<div class="container">
    <h1>Register with us:</h1>
    
    <form id="registrationForm" method="post" action="register.php">
    <span id="err"><?php 
    if($error_message){
        echo '*Error: '. $_GET['error'];
        echo '<style>#err{display:block !important;}</style>' ;
        }
    ?></span>
        <input type="text" name="firstName" placeholder="First Name" required>
        <input type="text" name="lastName" placeholder="Last Name" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="enrollmentNumber" placeholder="Enrollment Number" required>
        <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
        </select>
        <input type="tel" name="whatsappNumber" placeholder="WhatsApp Number" required>
        <input type="text" name="hostel" placeholder="Hostel" required>
        <input type="text" name="department" placeholder="Department" required>
        <input type="text" name="year" placeholder="Year" required>
        <input type="submit" value="Register">
    </form>
</div>
<?php require 'footer.php';?>
</body>
</html>
